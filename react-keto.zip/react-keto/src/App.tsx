import React from 'react'
import './App.css'
import CentralNavigation from './components/CentralNavigation'

function App() {
  return <CentralNavigation />
}

export default App
